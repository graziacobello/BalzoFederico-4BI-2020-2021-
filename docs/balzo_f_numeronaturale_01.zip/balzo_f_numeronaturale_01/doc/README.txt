# Program name: numeroNaturale.py 
---

## Programma 

descrivi programma 

### Requisiti 

python3 

## tagts 

boold, standard 

## Changelog 
01
2020-11-22: 
decrivi programma 

## Author 

Federico Balzo