# Program name: asta.py 
---

## Programma 

descrivi programma 

### Requisiti 

python3 

## tagts 

boold, standard 

## Changelog 
01
2020-11-17: 
decrivi programma 

## Author 

Federico Balzo