
package esercitazione;
import java.util.Scanner;


public class Esercitazione {

    
    public static void main(String[] args) {
        Scanner imp = new Scanner (System.in);
        int pop = 0;
        int tinf = 0;
        int inf = 1;
        System.out.print("inserisci la popolazione: ");
        pop = Integer.parseInt(imp.nextLine());
        System.out.print("\n inserisci il tasso di infettivita': ");
        tinf = Integer.parseInt(imp.nextLine());
        while (inf<(pop/2)){
            inf = tinf*inf;
        }
        System.out.println(inf);
        
        
    }
    
}
